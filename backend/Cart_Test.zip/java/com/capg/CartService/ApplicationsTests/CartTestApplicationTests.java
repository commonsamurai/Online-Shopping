package com.capg.CartService.ApplicationsTests;


import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CartTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
