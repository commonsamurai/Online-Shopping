package com.shopping.product;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductTestApplicationTests {

	@Test
	void contextLoads() {
	}

}

