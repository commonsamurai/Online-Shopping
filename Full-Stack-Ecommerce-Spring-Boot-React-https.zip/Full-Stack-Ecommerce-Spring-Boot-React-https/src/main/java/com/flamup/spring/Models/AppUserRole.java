package com.flamup.spring.Models;


public enum AppUserRole {
    USER,
    ADMIN
}
