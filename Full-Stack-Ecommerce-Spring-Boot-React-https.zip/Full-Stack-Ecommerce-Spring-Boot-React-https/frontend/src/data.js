module.exports = {

    data :[
       {
    "Unnamed: 0": 0,
    "sex": "MALE",
    "dresstype": "Round-neck T-shirt Regular Fit",
    "image": "lp2.hm.com/hmgoepprod?set=source[/d8/12/d812412329a628300624e1661969be84286fe637.jpg],origin[dam],category[men_tshirtstanks_shortsleeve],type[DESCRIPTIVESTILLLIFE],res[m],hmver[1]&call=url[file:/product/style]",
    "price": "Rs.399",
    "arrival": "old",
    "discount": 121
}, {
    "Unnamed: 0": 1,
    "sex": "MALE",
    "dresstype": "Round-neck T-shirt Regular Fit",
    "image": "lp2.hm.com/hmgoepprod?set=source[/2d/ef/2deff3457f9fe4ae80d4067a911589de047fa042.jpg],origin[dam],category[men_tshirtstanks_shortsleeve],type[LOOKBOOK],res[m],hmver[1]&call=url[file:/product/style]",
    "price": "Rs.399",
    "arrival": "old",
    "discount": 162
}, {
    "Unnamed: 0": 2,
    "sex": "MALE",
    "dresstype": "T-shirt with a motif",
    "image": "lp2.hm.com/hmgoepprod?set=source[/1d/08/1d08a141515f4f0319ecc5d75230dcbd6325977d.jpg],origin[dam],category[men_tshirtstanks_shortsleeve],type[LOOKBOOK],res[m],hmver[1]&call=url[file:/product/style]",
    "price": "Rs.799",
    "arrival": "old",
    "discount": 291
}, {
    "Unnamed: 0": 3,
    "sex": "MALE",
    "dresstype": "3-pack Regular Fit Polo shirts",
    "image": "lp2.hm.com/hmgoepprod?set=source[/98/7d/987daeb1d16e824fa87cf197b26771a79acb1854.jpg],origin[dam],category[],type[LOOKBOOK],res[m],hmver[1]&call=url[file:/product/style]",
    "price": "Rs.1,999",
    "arrival": "old",
    "discount": 334
}, {
    "Unnamed: 0": 4,
    "sex": "MALE",
    "dresstype": "Printed T-shirt",
    "image": "lp2.hm.com/hmgoepprod?set=source[/66/d0/66d0fac52e180b88822a86cd981a7978656f2b65.jpg],origin[dam],category[men_tshirtstanks_shortsleeve],type[LOOKBOOK],res[m],hmver[1]&call=url[file:/product/style]",
    "price": "Rs.599",
    "arrival": "new",
    "discount": 243
}, {
    "Unnamed: 0": 5,
    "sex": "MALE",
    "dresstype": "3-pack T-shirts Slim Fit",
    "image": "lp2.hm.com/hmgoepprod?set=source[/ab/60/ab600b99932bddedde3bbeeb997f9cae16bfeca8.jpg],origin[dam],category[men_tshirtstanks_shortsleeve],type[LOOKBOOK],res[m],hmver[1]&call=url[file:/product/style]",
    "price": "Rs.1,499",
    "arrival": "old",
    "discount": 1278
}, {
    "Unnamed: 0": 6,
    "sex": "MALE",
    "dresstype": "Round-neck T-shirt Regular Fit",
    "image": "lp2.hm.com/hmgoepprod?set=source[/ee/b2/eeb2604d496769701b620b7ff0cc6b67f26b3fca.jpg],origin[dam],category[men_tshirtstanks_shortsleeve],type[LOOKBOOK],res[m],hmver[1]&call=url[file:/product/style]",
    "price": "Rs.399",
    "arrival": "old",
    "discount": 388
}, {
    "Unnamed: 0": 7,
    "sex": "MALE",
    "dresstype": "Round-neck T-shirt Regular Fit",
    "image": "lp2.hm.com/hmgoepprod?set=source[/58/09/5809760b5e1943484403097b9c642a571bcf825d.jpg],origin[dam],category[],type[LOOKBOOK],res[m],hmver[1]&call=url[file:/product/style]",
    "price": "Rs.399",
    "arrival": "old",
    "discount": 332
}, {
    "Unnamed: 0": 8,
    "sex": "MALE",
    "dresstype": "3-pack jersey tops Regular Fit",
    "image": "lp2.hm.com/hmgoepprod?set=source[/34/4f/344f8df19359f80587755b067b543a80f8b582b9.jpg],origin[dam],category[men_tshirtstanks_longsleeve],type[LOOKBOOK],res[m],hmver[1]&call=url[file:/product/style]",
    "price": "Rs.1,999",
    "arrival": "old",
    "discount": 592
}, {
    "Unnamed: 0": 9,
    "sex": "MALE",
    "dresstype": "Round-neck T-shirt Regular Fit",
    "image": "lp2.hm.com/hmgoepprod?set=source[/91/a0/91a050fbaecd1caba940f6adfc631fb84dbecccc.jpg],origin[dam],category[men_tshirtstanks_shortsleeve],type[LOOKBOOK],res[m],hmver[1]&call=url[file:/product/style]",
    "price": "Rs.399",
    "arrival": "old",
    "discount": 193
}, {
    "Unnamed: 0": 10,
    "sex": "MALE",
    "dresstype": "Cotton T-shirt",
    "image": "lp2.hm.com/hmgoepprod?set=source[/65/c1/65c1e7fb98cec0c6e42b819fbecd7e3bc5414670.jpg],origin[dam],category[],type[LOOKBOOK],res[m],hmver[1]&call=url[file:/product/style]",
    "price": "Rs.799",
    "arrival": "old",
    "discount": 102
}, {
    "Unnamed: 0": 11,
    "sex": "MALE",
    "dresstype": "T-shirt Long Fit",
    "image": "lp2.hm.com/hmgoepprod?set=source[/f3/7a/f37aee371f02fe06744019c8bac509c1d17d8e2a.jpg],origin[dam],category[men_tshirtstanks_shortsleeve],type[LOOKBOOK],res[m],hmver[1]&call=url[file:/product/style]",
    "price": "Rs.699",
    "arrival": "old",
    "discount": 226
}, {
    "Unnamed: 0": 12,
    "sex": "MALE",
    "dresstype": "Round-neck T-shirt Regular Fit",
    "image": "lp2.hm.com/hmgoepprod?set=source[/a6/47/a64786443b2acf43fef06c56c47fcddcf8697abe.jpg],origin[dam],category[men_tshirtstanks_shortsleeve],type[LOOKBOOK],res[m],hmver[1]&call=url[file:/product/style]",
    "price": "Rs.399",
    "arrival": "old",
    "discount": 312
}, {
    "Unnamed: 0": 13,
    "sex": "MALE",
    "dresstype": "3-pack T-shirts Slim Fit",
    "image": "lp2.hm.com/hmgoepprod?set=source[/54/2f/542ff2a50871b2d9c86ba8db5b2a0c02b6499d66.jpg],origin[dam],category[men_tshirtstanks_shortsleeve],type[DESCRIPTIVESTILLLIFE],res[m],hmver[1]&call=url[file:/product/style]",
    "price": "Rs.1,499",
    "arrival": "old",
    "discount": 862
},
 {
    "Unnamed: 0": 821,
    "sex": "FEMALE",
    "dresstype": "Rib-knit dress",
    "image": "lp2.hm.com/hmgoepprod?set=source[/39/64/3964cf9eccdfe89c8ecbb49586756b2617ac2c26.jpg],origin[dam],category[],type[LOOKBOOK],res[m],hmver[1]&call=url[file:/product/style]",
    "price": "Rs.2,999",
    "arrival": "new",
    "discount": 705
}, {
    "Unnamed: 0": 822,
    "sex": "FEMALE",
    "dresstype": "Knitted dress",
    "image": "lp2.hm.com/hmgoepprod?set=source[/83/41/83412d6216fa00a7fc17867fd52085e33a80294b.jpg],origin[dam],category[],type[LOOKBOOK],res[m],hmver[1]&call=url[file:/product/style]",
    "price": "Rs.2,299",
    "arrival": "old",
    "discount": 1242
}, {
    "Unnamed: 0": 823,
    "sex": "FEMALE",
    "dresstype": "Ribbed dress",
    "image": "lp2.hm.com/hmgoepprod?set=source[/2d/49/2d49ed9b378f77b2138fb4cedc0316be430de0a2.jpg],origin[dam],category[],type[LOOKBOOK],res[m],hmver[1]&call=url[file:/product/style]",
    "price": "Rs.1,499",
    "arrival": "new",
    "discount": 1214
}, {
    "Unnamed: 0": 824,
    "sex": "FEMALE",
    "dresstype": "Puff-sleeved dress",
    "image": "lp2.hm.com/hmgoepprod?set=source[/82/af/82afbf3d4292adc2a7db0e1e19ebce9769461eef.jpg],origin[dam],category[],type[LOOKBOOK],res[m],hmver[1]&call=url[file:/product/style]",
    "price": "Rs.1,499",
    "arrival": "new",
    "discount": 1287
}, {
    "Unnamed: 0": 825,
    "sex": "FEMALE",
    "dresstype": "Button-front dress",
    "image": "lp2.hm.com/hmgoepprod?set=source[/44/b0/44b068781aafc99832cf8e9fbb5f7ac56083e2f5.jpg],origin[dam],category[],type[LOOKBOOK],res[m],hmver[1]&call=url[file:/product/style]",
    "price": "Rs.1,499",
    "arrival": "old",
    "discount": 834
}, {
    "Unnamed: 0": 826,
    "sex": "FEMALE",
    "dresstype": "Airy cotton dress",
    "image": "lp2.hm.com/hmgoepprod?set=source[/9c/1b/9c1bf17e18fcea0fd9d37a333ed2b81ab8727d90.jpg],origin[dam],category[],type[DESCRIPTIVESTILLLIFE],res[m],hmver[2]&call=url[file:/product/style]",
    "price": "Rs.1,499",
    "arrival": "new",
    "discount": 411
}, {
    "Unnamed: 0": 827,
    "sex": "FEMALE",
    "dresstype": "Long wrap dress",
    "image": "lp2.hm.com/hmgoepprod?set=source[/4d/42/4d4267f4ab21f7c5784d535aa94446a265b777c6.jpg],origin[dam],category[],type[LOOKBOOK],res[m],hmver[1]&call=url[file:/product/style]",
    "price": "Rs.2,299",
    "arrival": "old",
    "discount": 459
}, {
    "Unnamed: 0": 828,
    "sex": "FEMALE",
    "dresstype": "Calf-length T-shirt dress",
    "image": "lp2.hm.com/hmgoepprod?set=source[/0e/ab/0eabb9c010a6492c49979c065882a66adbdfa4be.jpg],origin[dam],category[],type[LOOKBOOK],res[m],hmver[1]&call=url[file:/product/style]",
    "price": "Rs.1,499",
    "arrival": "old",
    "discount": 926
}, {
    "Unnamed: 0": 829,
    "sex": "FEMALE",
    "dresstype": "Button-front dress",
    "image": "lp2.hm.com/hmgoepprod?set=source[/a7/04/a70467016c6f10b0df099612a867def1884cd690.jpg],origin[dam],category[],type[LOOKBOOK],res[m],hmver[1]&call=url[file:/product/style]",
    "price": "Rs.1,499",
    "arrival": "old",
    "discount": 1480
}, {
    "Unnamed: 0": 830,
    "sex": "FEMALE",
    "dresstype": "Shirt dress",
    "image": "lp2.hm.com/hmgoepprod?set=source[/97/a4/97a434949e029b2c4092ce1fdf05c931d450614f.jpg],origin[dam],category[],type[LOOKBOOK],res[m],hmver[1]&call=url[file:/product/style]",
    "price": "Rs.1,499",
    "arrival": "old",
    "discount": 634
}, {
    "Unnamed: 0": 831,
    "sex": "FEMALE",
    "dresstype": "Balloon-sleeved dress",
    "image": "lp2.hm.com/hmgoepprod?set=source[/28/c3/28c3c847b7be6f166f4927de26af352a1dc690e6.jpg],origin[dam],category[],type[DESCRIPTIVESTILLLIFE],res[m],hmver[2]&call=url[file:/product/style]",
    "price": "Rs.2,299",
    "arrival": "old",
    "discount": 101
}, {
    "Unnamed: 0": 832,
    "sex": "FEMALE",
    "dresstype": "Wrap dress",
    "image": "lp2.hm.com/hmgoepprod?set=source[/a4/02/a402c5c91d56e98af823d3aceef767fdbadfdceb.jpg],origin[dam],category[],type[DESCRIPTIVESTILLLIFE],res[m],hmver[2]&call=url[file:/product/style]",
    "price": "Rs.1,999",
    "arrival": "old",
    "discount": 1095
}, {
    "Unnamed: 0": 833,
    "sex": "FEMALE",
    "dresstype": "Straight dress",
    "image": "lp2.hm.com/hmgoepprod?set=source[/af/ac/afac8ebc2c6695a32459c91b274eb12bd8e120e3.jpg],origin[dam],category[],type[LOOKBOOK],res[m],hmver[1]&call=url[file:/product/style]",
    "price": "Rs.1,299",
    "arrival": "new",
    "discount": 445
}, {
    "Unnamed: 0": 834,
    "sex": "FEMALE",
    "dresstype": "Long V-neck dress",
    "image": "lp2.hm.com/hmgoepprod?set=source[/ec/8c/ec8c6dd28117773a49398b999ed060b7a5b5cb52.jpg],origin[dam],category[],type[LOOKBOOK],res[m],hmver[1]&call=url[file:/product/style]",
    "price": "Rs.2,699",
    "arrival": "old",
    "discount": 202
}, {
    "Unnamed: 0": 835,
    "sex": "FEMALE",
    "dresstype": "V-neck dress",
    "image": "lp2.hm.com/hmgoepprod?set=source[/b4/f6/b4f691b523d234eeccc542f2738fc1caae902917.jpg],origin[dam],category[],type[LOOKBOOK],res[m],hmver[1]&call=url[file:/product/style]",
    "price": "Rs.1,499",
    "arrival": "new",
    "discount": 173
}, {
    "Unnamed: 0": 836,
    "sex": "FEMALE",
    "dresstype": "Linen-blend wrapover dress",
    "image": "lp2.hm.com/hmgoepprod?set=source[/26/ba/26ba46e52c87ae619638b6237fd422e49c22e540.jpg],origin[dam],category[],type[LOOKBOOK],res[m],hmver[1]&call=url[file:/product/style]",
    "price": "Rs.2,999",
    "arrival": "new",
    "discount": 1080
}, {
    "Unnamed: 0": 837,
    "sex": "FEMALE",
    "dresstype": "Puff-sleeved dress",
    "image": "lp2.hm.com/hmgoepprod?set=source[/b8/b2/b8b269f5543619c59d0e1dbc94170467d1e10004.jpg],origin[dam],category[],type[LOOKBOOK],res[m],hmver[1]&call=url[file:/product/style]",
    "price": "Rs.2,299",
    "arrival": "old",
    "discount": 791
}, {
    "Unnamed: 0": 838,
    "sex": "FEMALE",
    "dresstype": "H&M+ Linen-blend dress",
    "image": "lp2.hm.com/hmgoepprod?set=source[/81/7f/817f010b52258397f4eedf2e843b70291525a95d.jpg],origin[dam],category[ladies_dresses_mididresses],type[LOOKBOOK],res[m],hmver[1]&call=url[file:/product/style]",
    "price": "Rs.2,299",
    "arrival": "old",
    "discount": 1321
}

    ]

}